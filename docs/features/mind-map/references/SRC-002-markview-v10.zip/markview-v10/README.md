# Карта исследования — approved prototype (v10)

- `prototype/index.html` — open it in a browser; it is self-contained and needs no server.
- `SPEC.md` — screens, states, flows, data, rules and requirement traceability.
- `CHANGES.md` — the review requests that shaped this version.

The prototype is the agreed behaviour and look. Implement the product to match it; where the prototype and SPEC.md differ, ask before choosing.
